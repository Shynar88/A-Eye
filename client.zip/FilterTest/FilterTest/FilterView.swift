//
//  FilterView.swift
//  FilterTest
//
//  Created by Shynar Torekhan on 14/01/2019.
//  Copyright © 2019 BPL. All rights reserved.
//

import UIKit

protocol FilterViewDelegate: class {
    func didPressOnce(sender: UITapGestureRecognizer)
    func didSwipeUp(sender: UISwipeGestureRecognizer)
    func didSwipeDown(sender: UISwipeGestureRecognizer)
}

//Code for creating GUI programmatically
class FilterView: UIView {
    let originalImageView = OriginalImageView()

    weak var delegate: FilterViewDelegate?
    init() {
        super.init(frame: .zero)
        addSubview(originalImageView)
        originalImageView.translatesAutoresizingMaskIntoConstraints = false
        originalImageView.centerXAnchor.constraint(equalTo: centerXAnchor, constant: 0).isActive = true
        originalImageView.centerYAnchor.constraint(equalTo: centerYAnchor, constant: 0).isActive = true
        originalImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(pressOnce)))
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(swipedUp))
        swipeUp.direction = .up
        originalImageView.addGestureRecognizer(swipeUp)
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(swipedDown))
        swipeDown.direction = .down
        originalImageView.addGestureRecognizer(swipeDown)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc
    private func swipedUp(sender: UISwipeGestureRecognizer) {
        delegate?.didSwipeUp(sender: sender)
    }
    
    @objc
    private func swipedDown(sender: UISwipeGestureRecognizer) {
        delegate?.didSwipeDown(sender: sender)
    }
    
    @objc
    private func pressOnce(sender: UITapGestureRecognizer) {
        delegate?.didPressOnce(sender: sender)
    }
}

class OriginalImageView: UIImageView {

    let screenSize: CGRect = UIScreen.main.bounds

    init() {
        super.init(frame: .zero)
        self.isUserInteractionEnabled = true
        widthAnchor.constraint(equalToConstant: screenSize.width).isActive = true
        heightAnchor.constraint(equalToConstant: screenSize.height).isActive = true
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
