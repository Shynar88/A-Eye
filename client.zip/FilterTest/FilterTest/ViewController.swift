//
//  ViewController.swift
//  FilterTest
//
//  Created by Shynar Torekhan on 14/01/2019.
//  Copyright © 2019 BPL. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire
import SwiftyJSON
import AFNetworking

class ViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    //setting up the view
    var filterView: FilterView {
        guard let custom = view as? FilterView else {
            return FilterView()
        }
        return custom
    }
    
    
    var takePhotoSingleTap = false
    var takePhotoSwipeUp = false
    var takePhotoSwipeDown = false
    // preparations for displaying camera output to the user
    var captureSession = AVCaptureSession()
    var backCamera: AVCaptureDevice?
    var frontCamera: AVCaptureDevice?
    var currentCamera: AVCaptureDevice?

    var photoOutput: AVCapturePhotoOutput?
    var orientation: AVCaptureVideoOrientation = .portrait

    let context = CIContext()

    override func viewDidLoad() {
        super.viewDidLoad()
        filterView.delegate = self
        setupDevice()
        setupInputOutput()
    }

    override func loadView() {
        view = FilterView()
    }

    override func viewDidLayoutSubviews() {
        orientation = AVCaptureVideoOrientation(rawValue: UIApplication.shared.statusBarOrientation.rawValue)!
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //requesting user's permission on usage of camera
        if AVCaptureDevice.authorizationStatus(for: AVMediaType.video) != .authorized
        {
            AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler:
                { (authorized) in
                    DispatchQueue.main.async
                        {
                            if authorized
                            {
                                self.setupInputOutput()
                            }
                    }
            })
        }
    }
    
    //helper functions for preparing device for displaying camera input
    func setupDevice() {
        let deviceDiscoverySession = AVCaptureDevice.DiscoverySession(deviceTypes: [AVCaptureDevice.DeviceType.builtInWideAngleCamera], mediaType: AVMediaType.video, position: AVCaptureDevice.Position.unspecified)
        let devices = deviceDiscoverySession.devices

        for device in devices {
            if device.position == AVCaptureDevice.Position.back {
                backCamera = device
            }
            else if device.position == AVCaptureDevice.Position.front {
                frontCamera = device
            }
        }

        currentCamera = backCamera
    }

    //helper functions for preparing device for displaying camera input
    func setupInputOutput() {
        do {
            setupCorrectFramerate(currentCamera: currentCamera!)
            let captureDeviceInput = try AVCaptureDeviceInput(device: currentCamera!)
            captureSession.sessionPreset = AVCaptureSession.Preset.hd1280x720
            if captureSession.canAddInput(captureDeviceInput) {
                captureSession.addInput(captureDeviceInput)
            }
            let videoOutput = AVCaptureVideoDataOutput()

            videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "sample buffer delegate", attributes: []))
            if captureSession.canAddOutput(videoOutput) {
                captureSession.addOutput(videoOutput)
            }
            captureSession.startRunning()
        } catch {
            print(error)
        }
    }

    //helper functions for preparing device for displaying camera input
    func setupCorrectFramerate(currentCamera: AVCaptureDevice) {
        for vFormat in currentCamera.formats {
            //see available types
            //print("\(vFormat) \n")

            let ranges = vFormat.videoSupportedFrameRateRanges as [AVFrameRateRange]
            let frameRates = ranges[0]

            do {
                //set to 240fps - available types are: 30, 60, 120 and 240 and custom
                // lower framerates cause major stuttering
                if frameRates.maxFrameRate == 240 {
                    try currentCamera.lockForConfiguration()
                    currentCamera.activeFormat = vFormat as AVCaptureDevice.Format
                    //for custom framerate set min max activeVideoFrameDuration to whatever you like, e.g. 1 and 180
                    currentCamera.activeVideoMinFrameDuration = frameRates.minFrameDuration
                    currentCamera.activeVideoMaxFrameDuration = frameRates.maxFrameDuration
                }
            }
            catch {
                print("Could not set active format")
                print(error)
            }
        }
    }

    //function rendering camera input to the screen and making operations on user interaction
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        connection.videoOrientation = orientation
        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue.main)
        
        let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer)
        let cameraImg = CIImage(cvImageBuffer: pixelBuffer!)
        let cameraImage : UIImage = self.convert(cmage: cameraImg)
        if takePhotoSingleTap {
            takePhotoSingleTap = false
            self.sendPhotoSingleTap(image: cameraImage)
        }
        if takePhotoSwipeUp {
            takePhotoSwipeUp = false
            self.sendPhotoSwipeUp(image: cameraImage)
        }
        if takePhotoSwipeDown {
            takePhotoSwipeDown = false
            self.sendPhotoSwipeDown(image: cameraImage)
        }
        DispatchQueue.main.async {
            self.filterView.originalImageView.image = cameraImage
        }
    }
    
    //function for using TTS
    func speakText(voiceOutdata: String ) {
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playAndRecord, mode: .default, options: .defaultToSpeaker)
            try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }

        let utterance = AVSpeechUtterance(string: voiceOutdata)
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")

        let synth = AVSpeechSynthesizer()
        synth.speak(utterance)

//        defer {
//            disableAVSession()
//        }
    }

    private func disableAVSession() {
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't disable.")
        }
    }
    
    // Convert CIImage to CGImage
    func convert(cmage:CIImage) -> UIImage
    {
         let context:CIContext = CIContext.init(options: nil)
         let cgImage:CGImage = context.createCGImage(cmage, from: cmage.extent)!
         let image:UIImage = UIImage.init(cgImage: cgImage)
         return image
    }
    
    let url = "http://87f0804b.ngrok.io"
    
    //client code for Image Captioning
    func sendPhotoSwipeUp(image: UIImage){
        let manager = AFHTTPRequestOperationManager()
        let pic = image.jpegData(compressionQuality: 0.5)
        
        manager.post("\(url)/swipeUp", parameters: nil,
                      constructingBodyWith: { (data: AFMultipartFormData!) in
                        data.appendPart(withFileData: pic, name: "file",fileName: "img.jpeg", mimeType: "image/jpeg")
                },
            success: { (operation: AFHTTPRequestOperation!,responseObject: Any?) in

                let json = JSON(responseObject)
                self.speakText(voiceOutdata: json["result"].string!)
                },
        failure: { (operation: AFHTTPRequestOperation!,error: Error!) in
            print("Error: \(error.localizedDescription)")
            })
        AudioServicesPlaySystemSound(1108);
        self.speakText(voiceOutdata: "Scene description in process")
    }
    
    // client code for OCR
    func sendPhotoSwipeDown(image: UIImage){
        let manager = AFHTTPRequestOperationManager()
        let pic = image.jpegData(compressionQuality: 0.5)
        
        manager.post("\(url)/swipeDown", parameters: nil,
                      constructingBodyWith: { (data: AFMultipartFormData!) in
                        data.appendPart(withFileData: pic, name: "file",fileName: "img.jpeg", mimeType: "image/jpeg")
                },
            success: { (operation: AFHTTPRequestOperation!,responseObject: Any?) in
                print("success")
                print(responseObject)
                let json = JSON(responseObject)
                self.speakText(voiceOutdata: json["result"].string!)
                
                },
        failure: { (operation: AFHTTPRequestOperation!,error: Error!) in
            print("Error: \(error.localizedDescription)")
            })
        AudioServicesPlaySystemSound(1108);
    }
    
    // client code for object detection
    func sendPhotoSingleTap(image: UIImage){
        let manager = AFHTTPRequestOperationManager()
        let pic = image.jpegData(compressionQuality: 0.5)
        
        manager.post("\(url)/picture", parameters: nil,
                      constructingBodyWith: { (data: AFMultipartFormData!) in
                        data.appendPart(withFileData: pic, name: "file",fileName: "img.jpeg", mimeType: "image/jpeg")
                },
            success: { (operation: AFHTTPRequestOperation!,responseObject: Any?) in

                let json = JSON(responseObject)
                self.speakText(voiceOutdata: json["result"].string!)
                },
        failure: { (operation: AFHTTPRequestOperation!,error: Error!) in
            print("Error: \(error.localizedDescription)")
            })
        AudioServicesPlaySystemSound(1108);
    
    }
}

extension ViewController: FilterViewDelegate {
    
    func didSwipeDown(sender: UISwipeGestureRecognizer) {
        print("Swipe down")
        self.takePhotoSwipeDown = true
    }
    
    func didSwipeUp(sender: UISwipeGestureRecognizer) {
        self.takePhotoSwipeUp = true
        print("Swipe up")
    }
    
    func didPressOnce(sender: UITapGestureRecognizer) {
        print("Tap once")
        self.takePhotoSingleTap = true
    }
}

